function c_animate_instance_timings(arg0, arg1, arg2, arg3 = -1)
{
    var _frame = arg1;
    var _frameCount = abs(arg2 - arg1);
    var _dir = ((arg2 - arg1) < 0) ? -1 : 1;
    
    for (var i = 0; i <= _frameCount; i++)
    {
        c_var_instance(arg0, "image_index", _frame);
        c_wait(arg3[i]);
        _frame += _dir;
        show_debug_message_concat(_frame);
    }
}
