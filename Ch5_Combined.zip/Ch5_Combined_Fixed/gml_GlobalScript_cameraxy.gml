function cameraxy()
{
    return new Vector2(camera_get_view_x(view_camera[0]), camera_get_view_y(view_camera[0]));
}
