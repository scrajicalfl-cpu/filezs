function c_msgfunc(arg0, arg1 = -1)
{
    c_cmd_x("msgcmd", "customfunc", arg1, arg0, 0, 0, 0);
}
