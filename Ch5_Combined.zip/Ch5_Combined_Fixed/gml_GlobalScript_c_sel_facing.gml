function c_sel_facing(arg0, arg1)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("facing", arg1, 0, 0, 0);
}
