function scr_bullet_inherit(arg0)
{
    if (i_ex(arg0))
    {
        if (damage != -1)
            arg0.damage = damage;
        
        if (grazepoints != -1)
            arg0.grazepoints = grazepoints;
        
        if (timepoints != -1)
            arg0.timepoints = timepoints;
        
        if (inv != -1)
            arg0.inv = inv;
        
        if (target != -1)
            arg0.target = target;
        
        if (grazed != -1)
            arg0.grazed = 0;
        
        if (grazetimer != -1)
            arg0.grazetimer = 0;
        
        if (object_index == obj_dbulletcontroller)
        {
            arg0.creatorid = creatorid;
            arg0.creator = creator;
        }
        
        arg0.element = element;
    }
}

function scr_bullet_inherit_from(arg0, arg1, arg2 = -1, arg3 = -1)
{
    if (i_ex(arg0) && i_ex(arg1))
    {
        if (arg2 == -1)
            arg0.damage = global.monsterat[arg1.myself] * 5;
        else
            arg0.damage = arg2;
        
        if (arg3 == -1)
            arg0.grazepoints = arg1.grazepoints;
        else
            arg0.grazepoints = arg3;
        
        arg0.timepoints = arg1.timepoints;
        arg0.inv = arg1.inv;
        arg0.target = arg1.mytarget;
        arg0.grazed = 0;
        arg0.grazetimer = 0;
        arg0.element = arg1.element;
        
        if (object_index == obj_dbulletcontroller)
        {
            arg0.creatorid = creatorid;
            arg0.argument0.creator = creator;
        }
    }
}
