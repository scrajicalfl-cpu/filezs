function scr_blconskip_boss(arg0)
{
    if (arg0 >= 0)
    {
        talktimer++;
        
        if ((button3_p() && talktimer > arg0) || !instance_exists(obj_writer))
        {
            with (obj_writer)
                instance_destroy();
            
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
    else if (arg0 == -1)
    {
        if (!instance_exists(obj_writer))
        {
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
    else if (arg0 == -2)
    {
        talktimer++;
        
        if (talktimer > 15)
            talktimer = talkmax;
        
        if (talktimer >= talkmax)
        {
            with (obj_writer)
                instance_destroy();
            
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
}
