function c_markerwalkdirect(arg0, arg1, arg2, arg3, arg4 = -1, arg5 = 0.25)
{
    c_cmd_x("markerwalkdirect", arg0, arg1, arg2, arg3, arg4, arg5);
}
