function c_imagenext(arg0)
{
    c_cmd_x("msgcmd", "imageindex", arg0, 0, 0, 0, 0);
}
