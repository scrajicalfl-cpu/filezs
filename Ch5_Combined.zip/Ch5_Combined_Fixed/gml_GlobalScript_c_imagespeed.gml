function c_imagespeed(arg0)
{
    c_cmd("imagespeed", arg0, 0, 0, 0);
}

function c_image_speed(arg0)
{
    c_cmd("imagespeed", arg0, 0, 0, 0);
}
