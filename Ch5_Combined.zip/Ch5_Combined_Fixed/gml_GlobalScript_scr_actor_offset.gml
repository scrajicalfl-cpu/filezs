function scr_actor_offset(arg0)
{
    var __offset = new Vector2();
    
    switch (arg0)
    {
        case "kr":
        case "kris":
            __offset = new Vector2(10, 37);
            break;
        
        case "su":
        case "susie":
            __offset = new Vector2(13, 44);
            break;
        
        case "ra":
        case "ralsei":
            __offset = new Vector2(11, 41);
            break;
    }
    
    return __offset;
}

function scr_actor_xoffset(arg0)
{
    return scr_actor_offset(arg0).x;
}

function scr_actor_yoffset(arg0)
{
    return scr_actor_offset(arg0).y;
}
