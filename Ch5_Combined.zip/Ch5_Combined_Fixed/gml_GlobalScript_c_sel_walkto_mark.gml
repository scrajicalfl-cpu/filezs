function c_sel_walkto_mark(arg0, arg1, arg2)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("walkdirect", arg1.x, arg1.y, arg2, 0);
}
