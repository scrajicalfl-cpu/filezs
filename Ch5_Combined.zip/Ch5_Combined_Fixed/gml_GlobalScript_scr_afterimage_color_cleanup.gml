function scr_afterimage_color_cleanup()
{
    if (variable_instance_exists(id, "trail_x"))
    {
        if (ds_exists(trail_x, ds_type_list))
        {
            ds_list_destroy(trail_x);
            ds_list_destroy(trail_y);
            ds_list_destroy(trail_xscale);
            ds_list_destroy(trail_yscale);
            ds_list_destroy(trail_img);
            ds_list_destroy(trail_spr);
            ds_list_destroy(alpha);
        }
    }
}
