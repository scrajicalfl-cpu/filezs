function c_msgcmd(arg0, arg1 = 0, arg2 = 0, arg3 = 0, arg4 = 0, arg5 = 0)
{
    c_cmd_x("msgcmd", arg0, arg1, arg2, arg3, arg4, arg5);
}
