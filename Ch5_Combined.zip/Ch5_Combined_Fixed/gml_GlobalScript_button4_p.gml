function button4_p()
{
    var _face = 32771;
    
    if (global.input_g[6] == gp_face3)
        _face = 32772;
    
    if (scr_debug() && gamepad_button_check_pressed(obj_gamecontroller.gamepad_id, _face))
        return 1;
}
