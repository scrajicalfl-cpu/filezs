function msgset_add(arg0, arg1, arg2, arg3 = 10, arg4 = 50, arg5 = -1)
{
    if (i_ex(obj_balloon_queue))
    {
        with (obj_balloon_queue)
        {
            ds_list_add(balloon_list, 
            {
                btext: arg0,
                xx: arg1,
                yy: arg2,
                btype: arg3,
                btyper: arg4,
                bfunc: arg5,
                bcaller: id
            });
        }
    }
    else
    {
        with (instance_create(0, 0, obj_balloon_queue))
        {
            ds_list_add(balloon_list, 
            {
                btext: arg0,
                xx: arg1,
                yy: arg2,
                btype: arg3,
                btyper: arg4,
                bfunc: arg5,
                bcaller: id
            });
        }
    }
}

function msgset_insert(arg0, arg1, arg2, arg3 = 10, arg4 = 50, arg5 = -1, arg6 = 0)
{
    if (i_ex(obj_balloon_queue))
    {
        with (obj_balloon_queue)
        {
            ds_list_insert(balloon_list, arg6, 
            {
                btext: arg0,
                xx: arg1,
                yy: arg2,
                btype: arg3,
                btyper: arg4,
                bfunc: arg5,
                bcaller: id
            });
        }
    }
    else
    {
        with (instance_create(0, 0, obj_balloon_queue))
        {
            ds_list_insert(balloon_list, arg6, 
            {
                btext: arg0,
                xx: arg1,
                yy: arg2,
                btype: arg3,
                btyper: arg4,
                bfunc: arg5,
                bcaller: id
            });
        }
    }
}

function msgset_replace(arg0 = 0, arg1, arg2, arg3, arg4 = 10, arg5 = 50, arg6 = -1)
{
    if (i_ex(obj_balloon_queue))
    {
        with (obj_balloon_queue)
        {
            ds_list_replace(balloon_list, arg0, 
            {
                btext: arg1,
                xx: arg2,
                yy: arg3,
                btype: arg4,
                btyper: arg5,
                bfunc: arg6,
                bcaller: id
            });
        }
    }
    else
    {
        with (instance_create(0, 0, obj_balloon_queue))
        {
            ds_list_replace(balloon_list, arg0, 
            {
                btext: arg1,
                xx: arg2,
                yy: arg3,
                btype: arg4,
                btyper: arg5,
                bfunc: arg6,
                bcaller: id
            });
        }
    }
}

function msgset_add_func(arg0 = -1)
{
    msgset_add("", 0, 0, -1, 50, arg0);
}

function msgset_insert_func(arg0 = -1, arg1 = 0)
{
    msgset_insert("", 0, 0, -1, 50, arg0, arg1);
}

function msgset_clear()
{
    with (obj_balloon_queue)
        instance_destroy();
}
