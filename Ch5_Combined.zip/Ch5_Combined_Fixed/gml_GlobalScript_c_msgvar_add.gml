function c_msgvar_add(arg0, arg1)
{
    c_cmd_x("msgcmd", "varadd", 0, arg0, arg1, 0, 0);
}

function c_msgvar_add_instance(arg0, arg1, arg2)
{
    c_cmd_x("msgcmd", "varadd", arg0, arg1, arg2, 0, 0);
}
