function c_pan_fancy(arg0, arg1, arg2, arg3 = 
{
    doround: true,
    easetype: "default"
})
{
    c_cmd("panfancy", arg0, arg1, arg2, arg3);
}

function c_panobj_fancy(arg0, arg1, arg2 = 
{
    doround: true,
    easetype: "default"
})
{
    c_cmd("panfancyobj", arg0, arg1, arg2);
}
