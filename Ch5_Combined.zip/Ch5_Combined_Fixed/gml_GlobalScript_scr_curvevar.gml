function scr_curvevar(arg0, arg1, arg2, arg3, arg4, arg5)
{
    __curvevar = scr_curvevar_instance(id, arg0, arg1, arg2, arg3, arg4, arg5);
    return __curvevar;
}

function scr_curvecol(arg0, arg1, arg2, arg3, arg4, arg5)
{
    __curvevar = scr_curvecol_instance(id, arg0, arg1, arg2, arg3, arg4, arg5);
    return __curvevar;
}
