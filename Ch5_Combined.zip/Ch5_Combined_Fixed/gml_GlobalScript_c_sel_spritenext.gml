function c_sel_spritenext(arg0, arg1, arg2 = -9999, arg3 = -9999, arg4 = -1)
{
    c_sel(arg0);
    c_cmd_x("msgcmd", "sprite", arg1, 0, 0, 0, 0);
    
    if (arg2 != -9999)
        c_cmd_x("msgcmd", "imageindex", arg2, 0, 0, 0, 0);
    
    if (arg3 != -9999)
        c_cmd_x("msgcmd", "imagespeed", arg3, 0, 0, 0, 0);
    
    if (arg4 >= 0)
        c_cmd("msgcmd", "autowalk", arg4, 0, 0);
}
