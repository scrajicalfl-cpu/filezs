function c_walkto_straight(arg0 = 
{
    x: 0,
    y: 0
}, arg1 = 
{
    x: 40,
    y: 40
}, arg2 = 4, arg3 = 0, arg4 = "")
{
    var disth = max(round(abs(arg0.x - arg1.x) / arg2), 1);
    var distv = max(round(abs(arg0.y - arg1.y) / arg2), 1);
    
    if (arg3 == 0)
    {
        if (distv > 0)
            c_walkdirect(arg0.x, arg1.y, distv);
        
        if (disth > 0)
            c_delaywalkdirect(distv + 1, arg1.x, arg1.y, disth);
    }
    else
    {
        if (distv > 0)
            c_walkdirect(arg1.x, arg0.y, disth);
        
        if (disth > 0)
            c_delaywalkdirect(disth + 1, arg1.x, arg1.y, distv);
    }
    
    var toface = "-1";
    
    if (is_string(arg4))
    {
        if (arg4 == "u" || arg4 == "U" || arg4 == "r" || arg4 == "R" || arg4 == "d" || arg4 == "D" || arg4 == "l" || arg4 == "L")
            toface = string_lower(arg4);
    }
    else
    {
        switch (arg4)
        {
            case 0:
                toface = "d";
                break;
            
            case 1:
                toface = "r";
                break;
            
            case 2:
                toface = "u";
                break;
            
            case 3:
                toface = "l";
                break;
        }
    }
    
    if (toface != "-1")
        c_delayfacing(disth + distv + 1, toface);
    
    return disth + distv;
}

function c_walktostraight_list(arg0, arg1 = [], arg2 = "-1", arg3 = 4)
{
    var totalwait = 0;
    
    for (var i = 0; i < array_length(arg1); i++)
    {
        var pref = "h";
        
        if (variable_struct_exists(arg1[i], "pref"))
        {
            if ((is_string(arg1[i].pref) && (arg1[i].pref == "v" || arg1[i].pref == "V")) || arg1[i].pref == 0)
                pref = "v";
        }
        
        var st = arg0;
        
        if (i > 0)
            st = arg1[i - 1].inst;
        
        var ed = arg1[i].inst;
        var thisspd = arg3;
        
        if (variable_struct_exists(arg1[i], "spd"))
            thisspd = arg1[i].spd;
        
        var disth = max(round(abs(st.x - ed.x) / thisspd), 0);
        var distv = max(round(abs(st.y - ed.y) / thisspd), 0);
        
        if (pref == "h")
        {
            if (disth > 0)
            {
                if (totalwait == 0)
                    c_walkdirect(ed.x, st.y, disth);
                else
                    c_delaywalkdirect(totalwait, ed.x, st.y, disth);
                
                totalwait += disth;
                show_debug_message_concat(i, ", distv=", disth);
            }
            
            if (distv > 0)
            {
                if (totalwait == 0)
                    c_walkdirect(ed.x, ed.y, distv);
                else
                    c_delaywalkdirect(totalwait, ed.x, ed.y, distv);
                
                totalwait += distv;
            }
        }
        else
        {
            if (distv > 0)
            {
                if (totalwait == 0)
                    c_walkdirect(st.x, ed.y, distv);
                else
                    c_delaywalkdirect(totalwait, st.x, ed.y, distv);
                
                totalwait += distv;
            }
            
            if (disth > 0)
            {
                if (totalwait == 0)
                    c_walkdirect(ed.x, ed.y, disth);
                else
                    c_delaywalkdirect(totalwait, ed.x, ed.y, disth);
                
                totalwait += disth;
            }
        }
    }
    
    var toface = "-1";
    
    if (is_string(arg2))
    {
        if (arg2 == "u" || arg2 == "U" || arg2 == "r" || arg2 == "R" || arg2 == "d" || arg2 == "D" || arg2 == "l" || arg2 == "L")
            toface = string_lower(arg2);
    }
    else
    {
        switch (arg2)
        {
            case 0:
                toface = "d";
                break;
            
            case 1:
                toface = "r";
                break;
            
            case 2:
                toface = "u";
                break;
            
            case 3:
                toface = "l";
                break;
        }
    }
    
    if (toface != "-1")
        c_delayfacing(totalwait + 1, toface);
    
    return totalwait;
}
