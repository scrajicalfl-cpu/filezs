function k_d(arg0 = 0)
{
    with (obj_dialoguer)
    {
        if (arg0 > 0)
        {
            var _stayer = instance_create_depth(x, y, depth + 1, obj_writer_stay);
            _stayer.side = side;
            _stayer.xoff = xoff;
            _stayer.yoff = yoff;
            _stayer.boxwidth = boxwidth;
            _stayer.boxheight = boxheight;
            _stayer.cur_jewel = cur_jewel;
            _stayer.doom = arg0;
            _stayer.c_border = c_border;
            _stayer.c_inner = c_inner;
        }
        
        instance_destroy();
    }
    
    with (obj_writer)
        instance_destroy();
    
    with (obj_choicer_neo)
        instance_destroy();
}
