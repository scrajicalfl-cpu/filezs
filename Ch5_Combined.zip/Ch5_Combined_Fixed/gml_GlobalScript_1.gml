__init_global();
