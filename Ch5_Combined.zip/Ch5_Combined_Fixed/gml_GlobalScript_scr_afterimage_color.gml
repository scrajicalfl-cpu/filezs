function scr_afterimage_color(arg0, arg1, arg2, arg3)
{
    if (!variable_instance_exists(id, "trail_x") || trail_x == -4)
    {
        trail_x = ds_list_create();
        trail_xscale = ds_list_create();
        trail_y = ds_list_create();
        trail_yscale = ds_list_create();
        trail_spr = ds_list_create();
        trail_img = ds_list_create();
        alpha = ds_list_create();
        number_of_after_images = arg0;
        spacing = arg1;
        fade_length = arg2;
        colour = arg3;
    }
    
    if (arg3 == -4)
        arg3 = 16777215;
    
    if (ds_list_size(trail_x) > number_of_after_images)
    {
        ds_list_delete(trail_spr, 0);
        ds_list_delete(trail_img, 0);
        ds_list_delete(trail_x, 0);
        ds_list_delete(trail_xscale, 0);
        ds_list_delete(trail_y, 0);
        ds_list_delete(trail_yscale, 0);
        ds_list_delete(alpha, 0);
    }
    
    for (var i = 1; i < ds_list_size(trail_x); i++)
        draw_sprite_ext(ds_list_find_value(trail_spr, i), ds_list_find_value(trail_img, i), ds_list_find_value(trail_x, i), ds_list_find_value(trail_y, i), ds_list_find_value(trail_xscale, i), ds_list_find_value(trail_yscale, i), image_angle, colour, ds_list_find_value(alpha, i));
    
    for (var i = 1; i < ds_list_size(trail_x); i++)
        ds_list_replace(alpha, i, ds_list_find_value(alpha, i) - fade_length);
    
    if (spacing <= 0)
    {
        ds_list_add(trail_spr, sprite_index);
        ds_list_add(trail_img, image_index);
        ds_list_add(trail_x, x);
        ds_list_add(trail_xscale, image_xscale);
        ds_list_add(trail_y, y);
        ds_list_add(trail_yscale, image_yscale);
        ds_list_add(alpha, 1);
        spacing = arg1;
    }
    else
    {
        spacing--;
    }
}
