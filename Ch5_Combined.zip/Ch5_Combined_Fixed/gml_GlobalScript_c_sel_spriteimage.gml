function c_sel_spriteimage(arg0, arg1, arg2, arg3 = -9999, arg4 = false)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("sprite", arg1, 0, 0, 0);
    c_cmd("imageindex", arg2, 0, 0, 0);
    
    if (arg3 != -9999)
    {
        c_cmd("imagespeed", arg3, 0, 0, 0);
        
        if (!arg4)
            c_cmd("autowalk", arg4, 0, 0, 0);
    }
}
