function c_msgvar(arg0, arg1)
{
    c_cmd_x("msgcmd", "var", 0, arg0, arg1, 0, 0);
}

function c_msgvar_instance(arg0, arg1, arg2)
{
    c_cmd_x("msgcmd", "var", arg0, arg1, arg2, 0, 0);
}
