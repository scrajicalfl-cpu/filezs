function scr_curvevar_instance(arg0, arg1, arg2, arg3, arg4, arg5, arg6)
{
    __curvevar = instance_create(0, 0, obj_curvevar);
    __curvevar.target = arg0;
    __curvevar.varname = arg1;
    __curvevar.pointa = arg4;
    __curvevar.pointb = arg5;
    __curvevar.maxtime = arg6;
    __curvevar.animcurve = arg2;
    __curvevar.channelname = arg3;
    return __curvevar;
}

function scr_curvecol_instance(arg0, arg1, arg2, arg3, arg4, arg5, arg6)
{
    __curvevar = instance_create(0, 0, obj_curvevar);
    __curvevar.target = arg0;
    __curvevar.varname = arg1;
    __curvevar.pointa = arg4;
    __curvevar.pointb = arg5;
    __curvevar.maxtime = arg6;
    __curvevar.animcurve = arg2;
    __curvevar.channelname = arg3;
    __curvevar.iscolor = true;
    return __curvevar;
}
