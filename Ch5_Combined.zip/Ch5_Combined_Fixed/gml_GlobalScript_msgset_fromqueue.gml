function msgset_fromqueue()
{
    if (!i_ex(obj_balloon_queue))
        exit;
    
    var new_balloon = -1;
    msgset(0, ds_list_find_value(obj_balloon_queue.balloon_list, 0).btext);
    
    if (ds_list_find_value(obj_balloon_queue.balloon_list, 0).btype != -1)
    {
        global.typer = ds_list_find_value(obj_balloon_queue.balloon_list, 0).btyper;
        var to_xx = ds_list_find_value(obj_balloon_queue.balloon_list, 0).xx;
        var to_yy = ds_list_find_value(obj_balloon_queue.balloon_list, 0).yy;
        
        if (is_method(ds_list_find_value(obj_balloon_queue.balloon_list, 0).xx))
            to_xx = (ds_list_find_value(obj_balloon_queue.balloon_list, 0)).xx();
        
        if (is_method(ds_list_find_value(obj_balloon_queue.balloon_list, 0).yy))
            to_yy = (ds_list_find_value(obj_balloon_queue.balloon_list, 0)).yy();
        
        new_balloon = scr_enemyblcon(to_xx, to_yy, ds_list_find_value(obj_balloon_queue.balloon_list, 0).btype);
    }
    
    talked = 1;
    talktimer = 0;
    rtimer = 0;
    
    if (ds_list_find_value(obj_balloon_queue.balloon_list, 0).bfunc != -1)
    {
        (ds_list_find_value(obj_balloon_queue.balloon_list, 0)).bfunc();
    }
    
    ds_list_delete(obj_balloon_queue.balloon_list, 0);
    
    if (ds_list_size(obj_balloon_queue.balloon_list) == 0)
        instance_destroy(obj_balloon_queue);
    
    return new_balloon;
}
