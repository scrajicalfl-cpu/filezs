function scr_actor_get_facing(arg0)
{
    var _facing = 0;
    
    if (arg0 == rsprite)
        _facing = 1;
    
    if (arg0 == usprite)
        _facing = 2;
    
    if (arg0 == lsprite)
        _facing = 3;
    
    return _facing;
}
