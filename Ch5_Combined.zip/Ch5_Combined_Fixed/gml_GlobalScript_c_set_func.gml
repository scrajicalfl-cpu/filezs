function c_set_func(arg0, arg1 = "step_func", arg2, arg3 = -1)
{
    if (arg3 == -1)
        arg3 = arg0.id;
    
    c_cmd("setfunc", arg0, arg1, arg2, arg3);
}
