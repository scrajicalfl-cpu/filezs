function scr_afterimager(arg0, arg1, arg2 = false, arg3 = -1)
{
    with (instance_create(x, y, obj_afterimager))
    {
        fog = arg3;
        creator = other.id;
        remaining = arg0;
        period = arg1;
        alarm[0] = period;
        rainbow_mode = arg2;
    }
}
