function c_spritenext(arg0, arg1 = -9999, arg2 = -9999)
{
    c_cmd_x("msgcmd", "sprite", arg0, 0, 0, 0, 0);
    
    if (arg1 != -9999)
        c_cmd_x("msgcmd", "imageindex", arg1, 0, 0, 0, 0);
    
    if (arg2 != -9999)
        c_cmd_x("msgcmd", "imagespeed", arg2, 0, 0, 0, 0);
}
