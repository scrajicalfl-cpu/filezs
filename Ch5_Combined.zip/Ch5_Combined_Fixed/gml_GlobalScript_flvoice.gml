function flvoice()
{
    if (global.flag[1391] == 1)
        return false;
    else
        return true;
}
