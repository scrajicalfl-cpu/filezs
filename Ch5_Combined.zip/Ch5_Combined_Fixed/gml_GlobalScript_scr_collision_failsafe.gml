function scr_collision_failsafe()
{
    var _check = instance_place(x, y, obj_plat_block);
    
    if (_check != -4)
    {
        if (x > _check.bbox_right)
            x = _check.bbox_right + abs(x - bbox_left);
        
        if (x < _check.bbox_left)
            x = _check.bbox_left - abs(x - bbox_right);
        
        if (y > _check.bbox_bottom)
            y = _check.bbox_bottom + abs(y - bbox_top);
        
        if (y < _check.bbox_top)
            y = _check.bbox_top - abs(y - bbox_bottom);
    }
}
