function ralseiHatState()
{
    var hatted = false;
    
    if (global.plot >= 230 && global.plot < 295)
        hatted = true;
    
    return hatted;
}
