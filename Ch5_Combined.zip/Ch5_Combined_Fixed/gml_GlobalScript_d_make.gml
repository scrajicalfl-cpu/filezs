function d_make(arg0 = -1, arg1 = -1, arg2 = -1, arg3 = -1, arg4 = -1)
{
    var _____d = instance_create(0, 0, obj_dialoguer);
    
    if (arg0 != -1)
        _____d.side = arg0;
    
    if (arg1 != -1)
        _____d.zurasu = arg1;
    
    if (arg2 != -1)
        _____d.stay = arg2;
    
    if (arg3 != -1)
        _____d.runcheck = arg3;
    
    if (arg4 != -1)
        _____d.preventcskip = arg3;
    
    return _____d;
}

function d_plat_exists(arg0)
{
    with (obj_dialoguer_plat)
    {
        if (priority >= arg0)
            return true;
    }
    
    return false;
}

function d_make_plat(arg0 = -1, arg1 = -1, arg2 = [], arg3 = -1, arg4 = -1, arg5 = false)
{
    with (obj_plat_foreground_writer)
        last_typer = -4;
    
    var _p = 10;
    
    if (arg1 != -1)
        _p = arg1;
    
    with (obj_dialoguer_plat)
    {
        if (priority <= _p)
            instance_destroy();
        else if (priority > _p)
            exit;
    }
    
    with (obj_choicer_neo)
        instance_destroy();
    
    var struct = {};
    
    if (arg0 != -1)
        struct.skippable = arg0;
    
    if (arg1 != -1)
        struct.priority = arg1;
    
    if (arg3 != -1)
        struct.draw_bg = arg3;
    
    if (arg4 != -1)
        struct.small = arg4;
    
    if (arg5 != false)
        struct.replace_round_with_floor = arg5;
    
    if (!arg0)
        struct.delays = arg2;
    
    var _____d = instance_create_depth(0, 0, 0, obj_dialoguer_plat, struct);
    return _____d;
}
