function scr_flowercutsceneFlag_get(arg0 = "")
{
    if (!variable_global_exists("flowercutsceneFlag_key_map"))
        scr_flowercutsceneFlag_key();
    
    if (ds_map_exists(global.flowercutsceneFlag_key_map, arg0))
    {
        var key_index = ds_map_find_value(global.flowercutsceneFlag_key_map, arg0);
        
        if (key_index < 16)
        {
            var flagvals = scr_bitmask_to_array(global.flag[1430], 16, 1);
            return flagvals[key_index];
        }
        else
        {
            var flagvals = scr_bitmask_to_array(global.flag[1892], 16, 1);
            return flagvals[key_index - 16];
        }
    }
    
    scr_debug_print("index: ", arg0, " not found");
}

function scr_flowercutsceneFlag_key()
{
    global.flowercutsceneFlag_key_map = ds_map_create();
    ds_map_set(global.flowercutsceneFlag_key_map, "cut1", 0);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut2", 1);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut3", 2);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut4", 3);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut4", 4);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut5", 5);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut6", 6);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut7", 7);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut8", 8);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut9", 9);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut10", 10);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut11", 11);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut12", 12);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut13", 13);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut14", 14);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut15", 15);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut15", 15);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut16", 16);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut17", 17);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut18", 18);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut19", 19);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut20", 20);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut21", 21);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut22", 22);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut23", 23);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut24", 24);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut25", 25);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut26", 26);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut27", 27);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut28", 28);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut29", 29);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut30", 30);
    ds_map_set(global.flowercutsceneFlag_key_map, "cut31", 31);
}

function scr_flowercutsceneFlag_set(arg0 = "", arg1 = 0)
{
    if (!is_numeric(arg1) || frac(arg1) != 0 || arg1 < 0 || arg1 > 1)
    {
        scr_debug_print("scr_flowercutsceneFlag_set(", arg0, ",", arg1, "): invalid");
        exit;
    }
    
    if (!variable_global_exists("flowercutsceneFlag_key_map"))
        scr_flowercutsceneFlag_key();
    
    if (ds_map_exists(global.flowercutsceneFlag_key_map, arg0))
    {
        var key_index = ds_map_find_value(global.flowercutsceneFlag_key_map, arg0);
        
        if (key_index < 16)
        {
            var flagvals = scr_bitmask_to_array(global.flag[1430], 16, 1);
            flagvals[key_index] = arg1;
            global.flag[1430] = scr_array_to_bitmask(flagvals, 1);
        }
        else
        {
            var flagvals = scr_bitmask_to_array(global.flag[1892], 16, 1);
            flagvals[key_index - 16] = arg1;
            global.flag[1892] = scr_array_to_bitmask(flagvals, 1);
        }
    }
    else
    {
        scr_debug_print("index: ", arg0, " not found");
    }
}

function scr_flowercutsceneWatchedFlag_get(arg0 = "")
{
    if (!variable_global_exists("flowercutsceneWatchedFlag_key_map"))
        scr_flowercutsceneWatchedFlag_key();
    
    if (ds_map_exists(global.flowercutsceneWatchedFlag_key_map, arg0))
    {
        var key_index = ds_map_find_value(global.flowercutsceneWatchedFlag_key_map, arg0);
        
        if (key_index < 16)
        {
            var flagvals = scr_bitmask_to_array(global.flag[1855], 16, 1);
            return flagvals[key_index];
        }
        else
        {
            var flagvals = scr_bitmask_to_array(global.flag[1893], 16, 1);
            return flagvals[key_index - 16];
        }
    }
    
    scr_debug_print("index: ", arg0, " not found");
}

function scr_flowercutsceneWatchedFlag_key()
{
    global.flowercutsceneWatchedFlag_key_map = ds_map_create();
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut1", 0);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut2", 1);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut3", 2);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut4", 3);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut4", 4);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut5", 5);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut6", 6);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut7", 7);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut8", 8);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut9", 9);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut10", 10);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut11", 11);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut12", 12);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut13", 13);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut14", 14);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut15", 15);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut15", 15);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut16", 16);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut17", 17);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut18", 18);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut19", 19);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut20", 20);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut21", 21);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut22", 22);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut23", 23);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut24", 24);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut25", 25);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut26", 26);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut27", 27);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut28", 28);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut29", 29);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut30", 30);
    ds_map_set(global.flowercutsceneWatchedFlag_key_map, "cut31", 31);
}

function scr_flowercutsceneWatchedFlag_set(arg0 = "", arg1 = 0)
{
    if (!is_numeric(arg1) || frac(arg1) != 0 || arg1 < 0 || arg1 > 1)
    {
        scr_debug_print("scr_flowercutsceneWatchedFlag_set(", arg0, ",", arg1, "): invalid");
        exit;
    }
    
    if (!variable_global_exists("flowercutsceneWatchedFlag_key_map"))
        scr_flowercutsceneWatchedFlag_key();
    
    if (ds_map_exists(global.flowercutsceneWatchedFlag_key_map, arg0))
    {
        var key_index = ds_map_find_value(global.flowercutsceneWatchedFlag_key_map, arg0);
        
        if (key_index < 16)
        {
            var flagvals = scr_bitmask_to_array(global.flag[1855], 16, 1);
            flagvals[key_index] = arg1;
            global.flag[1855] = scr_array_to_bitmask(flagvals, 1);
        }
        else
        {
            var flagvals = scr_bitmask_to_array(global.flag[1893], 16, 1);
            flagvals[key_index - 16] = arg1;
            global.flag[1893] = scr_array_to_bitmask(flagvals, 1);
        }
    }
    else
    {
        scr_debug_print("index: ", arg0, " not found");
    }
}
