function scr_copy_struct(arg0)
{
    var newCopy = {};
    var keys = variable_struct_get_names(arg0);
    var i = array_length(keys) - 1;
    
    while (i >= 0)
    {
        var key = keys[i];
        var value = variable_struct_get(arg0, key);
        variable_struct_get(arg0, key);
        variable_struct_set(newCopy, key, value);
        i--;
    }
    
    return newCopy;
}
