function distance_to_object_bbox(arg0 = id, arg1, arg2 = 0)
{
    var point1x = arg0.bbox_left + ((arg0.bbox_right - arg0.bbox_left) / 2);
    var point1y = arg0.bbox_top + ((arg0.bbox_bottom - arg0.bbox_top) / 2);
    var point2x = arg1.bbox_left + ((arg1.bbox_right - arg1.bbox_left) / 2);
    var point2y = arg1.bbox_top + ((arg1.bbox_bottom - arg1.bbox_top) / 2);
    return point_distance(point1x, point1y, point2x, point2y);
}

function direction_to_object_bbox(arg0 = id, arg1, arg2 = false, arg3 = 0)
{
    var point1x = arg0.bbox_left + ((arg0.bbox_right - arg0.bbox_left) / 2);
    var point1y = arg0.bbox_top + ((arg0.bbox_bottom - arg0.bbox_top) / 2);
    var point2x = arg1.bbox_left + ((arg1.bbox_right - arg1.bbox_left) / 2);
    var point2y = arg1.bbox_top + ((arg1.bbox_bottom - arg1.bbox_top) / 2);
    var dir = point_direction(point1x, point1y, point2x, point2y);
    
    if (arg2)
    {
        dir += 90;
        
        if (dir > 360)
            dir -= 360;
        
        dir = round(dir / 90);
        
        if (dir == 4)
            dir = 0;
    }
    
    return dir;
}
