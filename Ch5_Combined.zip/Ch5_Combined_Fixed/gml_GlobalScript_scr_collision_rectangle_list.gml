function scr_collision_rectangle_list()
{
    var __xx = argument0;
    var __yy = argument1;
    var __x2 = argument2;
    var __y2 = argument3;
    var __arr = argument4;
    var __targetlist = argument5;
    
    for (var i = 0; i < array_length(__arr); i++)
        collision_rectangle_list(__xx, __yy, __x2, __y2, __arr[i], false, false, __targetlist, false);
}
