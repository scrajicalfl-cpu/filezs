function scr_getcam()
{
    var ___cam = 
    {
        x: camera_get_view_x(view_camera[0]),
        y: camera_get_view_y(view_camera[0]),
        w: 640 * (2 - (global.darkzone == 0)) / 2,
        h: 480 * (2 - (global.darkzone == 0)) / 2
    };
    return ___cam;
}
