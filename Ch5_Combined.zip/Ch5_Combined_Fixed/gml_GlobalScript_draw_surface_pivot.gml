function draw_surface_pivot_ext(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9)
{
    arg3 *= arg5;
    arg4 *= arg6;
    
    if ((arg7 % 360) == 0)
    {
        draw_surface_ext(arg0, arg1 - arg3, arg2 - arg4, arg5, arg6, arg7, arg8, arg9);
    }
    else
    {
        var __len = point_distance(0, 0, arg3, arg4);
        var __dir = point_direction(arg3, arg4, 0, 0);
        var __xx = arg1 + lengthdir_x(__len, __dir + arg7);
        var __yy = arg2 + lengthdir_y(__len, __dir + arg7);
        draw_surface_ext(arg0, __xx, __yy, arg5, arg6, arg7, arg8, arg9);
    }
}
