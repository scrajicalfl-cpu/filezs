function draw_surface_centered_ext(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7)
{
    var __width = surface_get_width(arg0) * arg3;
    var __height = surface_get_height(arg0) * arg4;
    
    if ((arg5 % 360) == 0)
    {
        draw_surface_ext(arg0, arg1 - (__width / 2), arg2 - (__height / 2), arg3, arg4, arg5, arg6, arg7);
    }
    else
    {
        var __len = point_distance(0, 0, __width / 2, __height / 2);
        var __dir = point_direction(__width / 2, __height / 2, 0, 0);
        var __xx = arg1 + lengthdir_x(__len, __dir + arg5);
        var __yy = arg2 + lengthdir_y(__len, __dir + arg5);
        draw_surface_ext(arg0, __xx, __yy, arg3, arg4, arg5, arg6, arg7);
    }
}
