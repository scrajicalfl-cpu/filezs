function scr_color_correct(arg0, arg1, arg2 = 0)
{
    var __h = color_get_hue(arg0);
    var __s = color_get_saturation(arg0);
    var __v = color_get_value(arg0);
    __h = scr_loop(__h + arg1, 255);
    
    if (arg2 > 0)
        __s = lerp(__s, 255, arg2 / 100);
    else if (arg2 < 0)
        __s = lerp(__s, 0, -arg2 / 100);
    
    return make_color_hsv(__h, __s, __v);
}
