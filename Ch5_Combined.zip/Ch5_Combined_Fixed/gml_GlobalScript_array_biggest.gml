function array_biggest(arg0 = [])
{
    var biggest = 0;
    
    for (var i = 0; i < array_length(arg0); i++)
        biggest = max(biggest, arg0[i]);
    
    return biggest;
}

function array_smallest(arg0 = [])
{
    var smallest = 0;
    
    for (var i = 0; i < array_length(arg0); i++)
        smallest = min(smallest, arg0[i]);
    
    return smallest;
}

function array_average(arg0 = [])
{
    var avg = 0;
    
    for (var i = 0; i < array_length(arg0); i++)
        avg += arg0[i];
    
    return avg / array_length(arg0);
}
