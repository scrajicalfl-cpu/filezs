function c_delaycmd(arg0, arg1, arg2, arg3 = 0, arg4 = 0, arg5 = 0)
{
    c_cmd_x("delaycmd", arg0, arg1, arg2, arg3, arg4, arg5);
}
