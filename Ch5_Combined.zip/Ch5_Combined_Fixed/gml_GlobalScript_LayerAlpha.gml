function scr_layer_alpha_begin()
{
    if (event_number == 0)
    {
        with (obj_battleLayerHighlight)
        {
            shader_replace_simple_set_hook(33);
            shader_set_uniform_f(shader_get_uniform(shd_alpha, "alpha"), myalpha);
        }
    }
}

function scr_layer_alpha_end()
{
    if (shader_current() != -1)
        shader_replace_simple_reset_hook();
}
