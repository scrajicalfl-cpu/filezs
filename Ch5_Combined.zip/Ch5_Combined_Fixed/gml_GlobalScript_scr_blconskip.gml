function scr_blconskip(arg0)
{
    if (arg0 >= 0)
    {
        if (button1_p() && talktimer > arg0)
            talktimer = talkmax;
        
        talktimer++;
        
        if (talktimer >= talkmax)
        {
            with (obj_writer)
                instance_destroy();
            
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
    else if (arg0 == -1)
    {
        if (!instance_exists(obj_writer))
        {
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
    else if (arg0 == -2)
    {
        talktimer++;
        
        if (talktimer > 15)
            talktimer = talkmax;
        
        if (talktimer >= talkmax)
        {
            with (obj_writer)
                instance_destroy();
            
            if (i_ex(obj_balloon_queue))
                msgset_fromqueue();
            else
                global.mnfight = 1.5;
        }
    }
}
