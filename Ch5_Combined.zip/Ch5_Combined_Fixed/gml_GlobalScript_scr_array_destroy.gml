function scr_array_destroy(arg0, arg1 = -1)
{
    var _size = arg1;
    
    if (arg1 == -1)
        _size = array_length(arg0);
    
    for (var i = 0; i < _size; i++)
        safe_delete(arg0[i]);
    
    arg0 = [];
    return arg0;
}
