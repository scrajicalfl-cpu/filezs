function c_customfunc(arg0, arg1 = -1)
{
    if (instance_exists(obj_cutscene_master))
    {
        with (obj_cutscene_master)
            array_push(customfuncs, arg0);
        
        c_cmd("customfunc", arg1, 0, 0, 0);
    }
}
