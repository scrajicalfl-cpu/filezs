function c_spriteimage(arg0, arg1, arg2 = -999)
{
    c_cmd("sprite", arg0, 0, 0, 0);
    c_cmd("imageindex", arg1, 0, 0, 0);
    
    if (arg2 != -999)
    {
        c_cmd("imagespeed", arg2, 0, 0, 0);
        
        if (arg2 == 0)
            c_cmd("autowalk", false, 0, 0, 0);
    }
}
