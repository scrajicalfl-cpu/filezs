function c_delay_msgcmd(arg0, arg1, arg2 = 0, arg3 = 0, arg4 = 0)
{
    c_cmd_x("msgcmd", "delaycmd", arg0, arg1, arg2, arg3, arg4);
}
