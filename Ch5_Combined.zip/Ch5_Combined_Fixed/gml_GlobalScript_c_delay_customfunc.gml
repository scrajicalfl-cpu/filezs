function c_delay_customfunc(arg0, arg1, arg2 = -1)
{
    if (instance_exists(obj_cutscene_master))
        c_cmd_x("delaycmd", arg0, "customfunc", arg2, arg1, 0, 0);
}
