function dec_to_hex(arg0)
{
    var hex_string = "";
    var digits = "0123456789ABCDEF";
    arg0 = clamp(round(arg0), 0, 16777215);
    
    for (var i = 0; i < 6; i++)
    {
        var digit_val = arg0 & 15;
        hex_string = string_char_at(digits, digit_val + 1) + hex_string;
        arg0 = arg0 >> 4;
    }
    
    return "#" + string_copy(hex_string, 5, 2) + string_copy(hex_string, 3, 2) + string_copy(hex_string, 0, 2);
}
