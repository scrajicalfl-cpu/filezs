function flrainbow()
{
    var rainbow = [];
    array_push(rainbow, 255);
    array_push(rainbow, 45311);
    array_push(rainbow, 65535);
    array_push(rainbow, 3663159);
    array_push(rainbow, 16773632);
    array_push(rainbow, 15623011);
    array_push(rainbow, 16711922);
    return rainbow;
}
