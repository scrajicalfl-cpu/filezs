function draw_pie(arg0, arg1, arg2, arg3, arg4, arg5, arg6)
{
    if (argument2 > 0)
    {
        var numberofsections = 60;
        var sizeofsection = 360 / numberofsections;
        var val = (argument2 / argument3) * numberofsections;
        
        if (val > 1)
        {
            draw_set_colour(argument4);
            draw_set_alpha(argument6);
            draw_primitive_begin(pr_trianglefan);
            draw_vertex(argument0, argument1);
            
            for (var i = 0; i <= val; i++)
            {
                var len = (i * sizeofsection) + 90;
                var tx = lengthdir_x(argument5, len);
                var ty = lengthdir_y(argument5, len);
                draw_vertex(argument0 + tx, argument1 + ty);
            }
            
            draw_primitive_end();
        }
        
        draw_set_alpha(1);
    }
}
