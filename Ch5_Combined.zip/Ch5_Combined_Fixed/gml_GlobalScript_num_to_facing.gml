function scr_num_to_facing(arg0 = 0)
{
    var dirlet = "d";
    
    switch (arg0)
    {
        case 0:
            dirlet = "d";
            break;
        
        case 1:
            dirlet = "r";
            break;
        
        case 2:
            dirlet = "u";
            break;
        
        case 3:
            dirlet = "k";
            break;
    }
    
    return dirlet;
}

function scr_letter_to_facing(arg0 = "d")
{
    var dirnum = "d";
    
    switch (arg0)
    {
        case "d":
        case "D":
            dirnum = 0;
            break;
        
        case "r":
        case "R":
            dirnum = 1;
            break;
        
        case "u":
        case "U":
            dirnum = 2;
            break;
        
        case "l":
        case "L":
            dirnum = 3;
            break;
    }
    
    return dirnum;
}
