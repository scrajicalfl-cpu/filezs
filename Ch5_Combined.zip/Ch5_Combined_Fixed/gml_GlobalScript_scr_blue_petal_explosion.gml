function scr_blue_petal_explosion()
{
    var randangle = choose(0, 22.5, -22.5);
    
    for (a = 0; a < 8; a++)
    {
        with (scr_fire_bullet(x, y, obj_regularbullet, (45 * a) + randangle, 9, spr_enemy_blue_bullet_petal, 0, true))
        {
            speed -= ((other.a % 2) * 3);
            image_xscale = 1;
            image_yscale = 4;
            image_angle = direction;
            gravity_direction = direction;
            friction = -0.3;
            scr_lerpvar("speed", speed, 1, 8);
            scr_lerpvar("image_xscale", 1, 2, 8);
            scr_lerpvar("image_yscale", 4, 2, 8);
        }
    }
    
    snd_play(snd_bomb);
    beam_x = obj_yellow_enemy.x;
    beam_y = obj_yellow_enemy.y + 46;
    
    with (instance_create_depth(x, y, depth - 1, obj_yellow_beam))
        setup(obj_yellow_enemy.x, obj_yellow_enemy.y + 46, x, y, 12, 0, 16, 8, 32);
    
    instance_destroy();
}
