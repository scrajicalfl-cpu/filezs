function c_plat_action(arg0, arg1)
{
    c_cmd("plat_action", arg0, arg1, 0, 0);
}

function c_plat_stop_action(arg0)
{
    c_cmd("plat_stop_action", arg0, 0, 0, 0);
}

function c_plat_animate(arg0, arg1, arg2 = false)
{
    c_cmd("plat_animate", arg0, arg1, arg2, 0);
}

function c_plat_stop_animation(arg0)
{
    c_cmd("plat_stop_animation", arg0, 0, 0, 0);
}

function c_plat_moveto(arg0, arg1, arg2 = 0)
{
    c_cmd("plat_moveto", arg0, arg1, arg2, 0);
}

function c_plat_turn(arg0, arg1)
{
    if (arg1 == "r" || arg1 == "right")
        c_cmd("plat_turn", arg0, true, 0, 0);
    else
        c_cmd("plat_turn", arg0, false, 0, 0);
}

function c_plat_goal_reached(arg0, arg1 = 90)
{
    c_cmd("plat_goal_reached", arg0, arg1, 0, 0);
}

function c_plat_prepare_followers()
{
    c_cmd("plat_prepare_followers", 0, 0, 0, 0);
}

function c_plat_followers_to_caterpillar()
{
    c_cmd("plat_followers_to_caterpillar", 0, 0, 0, 0);
}

function scr_match_plat_objects(arg0)
{
    if (object_index == obj_plat_npc)
        set_sprite_simple(arg0.sprite_index, true);
    else
        set_sprite_simple(arg0.sprite_draw);
    
    image_xscale = arg0.image_xscale;
    var x_center = (x - (sprite_get_xoffset(sprite_index) * image_xscale)) + (0.5 * sprite_width);
    var other_x_center = (arg0.x - (sprite_get_xoffset(arg0.sprite_index) * arg0.image_xscale)) + (0.5 * arg0.sprite_width);
    var x_diff = x_center - other_x_center;
    var y_diff = bbox_bottom - arg0.bbox_bottom;
    x -= x_diff;
    y -= y_diff;
    create_x_diff = x_diff;
    create_y_diff = y_diff;
    entity_gravity = arg0.entity_gravity;
    hspeed = arg0.hspeed;
    vspeed = arg0.vspeed;
    grounded = arg0.grounded;
    groundedprev = arg0.groundedprev;
    state = arg0.state;
    target = arg0.target;
    jumping = arg0.jumping;
    depth = arg0.depth;
}

function scr_maincharacters_actors_plat()
{
    actor_count = 0;
    kr = 0;
    kr_actor = instance_create(obj_plat_player.x, obj_plat_player.y, obj_plat_npc);
    kr_actor.get_preset(0);
    kr_actor.name = "kris";
    scr_actor_setup(kr, kr_actor, "kris");
    
    with (kr_actor)
        scr_match_plat_objects(910);
    
    with (obj_plat_player)
        visible = 0;
    
    obj_plat_player.cutscene = 1;
    var __jj = 0;
    
    with (obj_plat_follower)
    {
        caterpillarmode = 0;
        
        if (name == "susie")
        {
            with (other)
            {
                actor_count++;
                su = __jj + 1;
                __jj++;
                su_actor = instance_create(other.x, other.y, obj_plat_npc);
                su_actor.get_preset(1);
                name = "susie";
                scr_actor_setup(su, su_actor, "susie");
                var su_obj = other;
                
                with (su_actor)
                    scr_match_plat_objects(su_obj);
                
                other.visible = 0;
            }
        }
        else if (name == "ralsei")
        {
            with (other)
            {
                actor_count++;
                ra = __jj + 1;
                __jj++;
                ra_actor = instance_create(other.x, other.y, obj_plat_npc);
                ra_actor.get_preset(2);
                name = "ralsei";
                scr_actor_setup(ra, ra_actor, "ralsei");
                var ra_obj = other;
                
                with (ra_actor)
                    scr_match_plat_objects(ra_obj);
                
                other.visible = 0;
            }
        }
    }
}

function scr_setup_plat_actor(arg0, arg1)
{
    actor_count++;
    arg0.name = arg1;
    scr_actor_setup(actor_count, arg0, arg1);
    return actor_count;
}
