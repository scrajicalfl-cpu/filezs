live_shader_updated = function(arg0, arg1, arg2)
{
    shader_replace_simple(shader_index, vertex_hlsl_code, pixel_hlsl_code);
    show_debug_message_concat("updating shader....");
};
