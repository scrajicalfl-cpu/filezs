function c_sel_walk(arg0, arg1, arg2, arg3)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("walk", arg1, arg2, arg3, 0);
}
