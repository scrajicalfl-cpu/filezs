function c_step_func(arg0)
{
    c_cmd("stepfunc", argument0, 0, 0, 0);
}

function c_draw_func(arg0)
{
    c_cmd("drawfunc", argument0, 0, 0, 0);
}
