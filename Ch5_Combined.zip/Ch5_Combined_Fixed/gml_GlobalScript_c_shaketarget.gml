function c_shaketarget(arg0)
{
    c_cmd("shaketarget", arg0, 0, 0, 0);
}
