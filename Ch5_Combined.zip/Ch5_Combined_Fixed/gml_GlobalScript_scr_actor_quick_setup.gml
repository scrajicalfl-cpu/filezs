function scr_actor_quick_setup(arg0, arg1, arg2, arg3 = "auto")
{
    var __actor = instance_create(arg0.x, arg0.y, obj_actor);
    scr_actor_setup(arg1, __actor, arg2);
    __actor.sprite_index = arg0.sprite_index;
    
    if (arg3 == "auto")
    {
        __actor.auto_depth = true;
    }
    else
    {
        __actor.auto_depth = false;
        __actor.depth = arg3;
    }
    
    return __actor;
}
