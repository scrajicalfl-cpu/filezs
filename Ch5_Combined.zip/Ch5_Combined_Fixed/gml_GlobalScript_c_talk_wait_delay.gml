function c_talk_wait_delay(arg0)
{
    c_talk();
    c_wait(arg0);
    c_wait_talk();
}
