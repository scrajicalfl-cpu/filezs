function scr_animate_time(arg0, arg1 = 1, arg2 = id, arg3 = 0)
{
    with (arg2)
    {
        if (sprite_exists(sprite_index))
        {
            var imgCount = sprite_get_number(sprite_index) - 1;
            image_speed = 0;
            var thisLerp = scr_lerpvar("image_index", arg3, arg3 + (imgCount * arg1), arg0);
            extflag = "animate";
            return thisLerp;
        }
    }
}

function scr_animate_speed(arg0, arg1 = 1, arg2 = id, arg3 = 0)
{
    with (arg2)
    {
        if (sprite_exists(sprite_index))
        {
            var imgCount = sprite_get_number(sprite_index) - 1;
            var imgTime = ceil((arg3 + (imgCount * arg1)) / arg0);
            image_speed = 0;
            var thisLerp = scr_lerpvar("image_index", arg3, arg3 + (imgCount * arg1), imgTime);
            extflag = "animate";
            return thisLerp;
        }
    }
}
