function scr_choiceradjust(arg0 = 0, arg1 = 0, arg2 = 0, arg3 = 0, arg4 = 0, arg5 = 0, arg6 = 0, arg7 = 0, arg8 = 0, arg9 = 0)
{
    var choiceradjuster = instance_create_depth(0, 0, 0, obj_object);
    
    with (choiceradjuster)
    {
        __opt0xoff = arg0;
        __opt0yoff = arg1;
        __opt1xoff = arg2;
        __opt1yoff = arg3;
        __opt2xoff = arg4;
        __opt2yoff = arg5;
        __opt3xoff = arg6;
        __opt3yoff = arg7;
        __heartxoff = arg8;
        __heartyoff = arg9;
        scr_debug_print("CREATED");
        
        begin_step_func = function()
        {
            var done = false;
            
            with (obj_choicer_neo)
            {
                opt0xoff = other.__opt0xoff / 2;
                opt0yoff = other.__opt0yoff / 2;
                opt1xoff = other.__opt1xoff / 2;
                opt1yoff = other.__opt1yoff / 2;
                opt2xoff = other.__opt2xoff / 2;
                opt2yoff = other.__opt2yoff / 2;
                opt3xoff = other.__opt3xoff / 2;
                opt3yoff = other.__opt3yoff / 2;
                heartxoff = other.__heartxoff;
                heartyoff = other.__heartyoff;
                done = true;
            }
            
            if (done)
            {
                scr_debug_print("donezo");
                instance_destroy();
            }
        };
    }
    
    return choiceradjuster;
}
