function draw_sprite_skew_nocrop(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8)
{
    var __spritedata = sprite_get_info(arg0);
    var __frame = __spritedata.frames[arg1 % array_length(__spritedata.frames)];
    var __h = __frame.h * arg4;
    var __w = __frame.w * arg5;
    var __xoff = __frame.x_offset * arg4;
    var __yoff = __frame.y_offset * arg5;
    var __halfw = (__spritedata.width * arg4) / 2;
    var __halfh = (__spritedata.height * arg5) / 2;
    arg7 *= arg4;
    arg8 *= arg5;
}
