function scr_afterimage_monochrome(arg0, arg1)
{
    afterimage = instance_create(x, y, obj_afterimage_onecolor);
    afterimage.tint = arg0;
    afterimage.additive = arg1;
    afterimage.sprite_index = sprite_index;
    afterimage.image_index = image_index;
    afterimage.image_blend = image_blend;
    afterimage.image_speed = 0;
    afterimage.depth = depth;
    afterimage.image_xscale = image_xscale;
    afterimage.image_yscale = image_yscale;
    afterimage.image_angle = image_angle;
    return afterimage;
}

function scr_afterimage_monochrome_parallax(arg0, arg1, arg2)
{
    afterimage = instance_create(x, y, obj_afterimage_onecolor_parallax);
    afterimage.tint = arg0;
    afterimage.additive = arg1;
    afterimage.sprite_index = sprite_index;
    afterimage.image_index = image_index;
    afterimage.image_blend = image_blend;
    afterimage.image_speed = 0;
    afterimage.depth = depth;
    afterimage.image_xscale = image_xscale;
    afterimage.image_yscale = image_yscale;
    afterimage.image_angle = image_angle;
    afterimage.parallax_depth = arg2;
    return afterimage;
}
