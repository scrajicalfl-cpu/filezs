function button1_p()
{
    if (global.input_pressed[4])
    {
        return 1;
    }
    else if (global.input_pressed[7])
    {
        return 1;
    }
    else if (gamepad_button_check_pressed(obj_gamecontroller.gamepad_id, gp_shoulderlb))
    {
        if (!obj_gamecontroller.gamepad_shoulderlb_reassign)
            return 1;
    }
}

function button1_h()
{
    if (global.input_held[4])
        return 1;
    
    if (global.input_held[7])
    {
        return 1;
    }
    else if (gamepad_button_check(obj_gamecontroller.gamepad_id, gp_shoulderlb))
    {
        if (!obj_gamecontroller.gamepad_shoulderlb_reassign)
            return 1;
    }
}

function button1_r()
{
    if (global.input_released[4])
        return 1;
    
    if (global.input_released[7])
    {
        return 1;
    }
    else if (gamepad_button_check_released(obj_gamecontroller.gamepad_id, gp_shoulderlb))
    {
        if (!obj_gamecontroller.gamepad_shoulderlb_reassign)
            return 1;
    }
}
