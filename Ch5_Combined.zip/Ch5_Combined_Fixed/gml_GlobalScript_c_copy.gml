function c_copy(arg0, arg1 = true, arg2 = true, arg3 = true, arg4 = true, arg5 = true, arg6 = true, arg7 = false, arg8 = false, arg9 = false, arg10 = false)
{
    if (!is_undefined(arg0))
    {
        if (arg1 && variable_struct_exists(arg0, "x"))
            c_var("x", arg0.x);
        
        if (arg2 && variable_struct_exists(arg0, "y"))
            c_var("y", arg0.y);
        
        if (arg3 && variable_struct_exists(arg0, "sprite_index"))
            c_var("sprite_index", arg0.sprite_index);
        
        if (arg7 && variable_struct_exists(arg0, "image_index"))
            c_var("image_index", arg0.image_index);
        
        if (arg6 && variable_struct_exists(arg0, "image_angle"))
            c_var("image_angle", arg0.image_angle);
        
        if (arg8 && variable_struct_exists(arg0, "image_blend"))
            c_var("image_blend", arg0.image_blend);
        
        if (arg4 && variable_struct_exists(arg0, "image_xscale"))
            c_var("image_xscale", arg0.image_xscale);
        
        if (arg5 && variable_struct_exists(arg0, "image_yscale"))
            c_var("image_yscale", arg0.image_yscale);
        
        if (arg9 && variable_struct_exists(arg0, "image_speed"))
            c_var("image_speed", arg0.image_speed);
        
        if (arg10 && variable_struct_exists(arg0, "image_alpha"))
            c_var("image_alpha", arg0.image_alpha);
    }
}

function scr_copy(arg0, arg1 = true, arg2 = true, arg3 = true, arg4 = true, arg5 = true, arg6 = true, arg7 = false, arg8 = false, arg9 = false, arg10 = false)
{
    if (!is_undefined(arg0))
    {
        if (arg1 && variable_struct_exists(arg0, "x"))
            x = arg0.x;
        
        if (arg2 && variable_struct_exists(arg0, "y"))
            y = arg0.y;
        
        if (arg3 && variable_struct_exists(arg0, "sprite_index"))
            sprite_index = arg0.sprite_index;
        
        if (arg7 && variable_struct_exists(arg0, "image_index"))
            image_index = arg0.image_index;
        
        if (arg6 && variable_struct_exists(arg0, "image_angle"))
            image_angle = arg0.image_angle;
        
        if (arg8 && variable_struct_exists(arg0, "image_blend"))
            image_blend = arg0.image_blend;
        
        if (arg4 && variable_struct_exists(arg0, "image_xscale"))
            image_xscale = arg0.image_xscale;
        
        if (arg5 && variable_struct_exists(arg0, "image_yscale"))
            image_yscale = arg0.image_yscale;
        
        if (arg9 && variable_struct_exists(arg0, "image_speed"))
            image_speed = arg0.image_speed;
        
        if (arg10 && variable_struct_exists(arg0, "image_alpha"))
            image_alpha = arg0.image_alpha;
    }
}
