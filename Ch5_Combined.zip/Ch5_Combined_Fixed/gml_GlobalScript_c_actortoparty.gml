function c_actortoparty()
{
    c_cmd("actortoparty", 0, 0, 0, 0);
}

function c_actortoparty_function()
{
    var actor_count = array_length(actor_id);
    
    for (var jjj = 0; jjj < actor_count; jjj++)
    {
        if (actor_name[jjj] == "kris" && i_ex(actor_id[jjj]))
        {
            setxy(actor_id[jjj].x, actor_id[jjj].y, 1198);
            obj_mainchara.depth = actor_id[jjj].depth;
            
            switch (actor_id[jjj].facing)
            {
                case "d":
                    global.facing = 0;
                    break;
                
                case "r":
                    global.facing = 1;
                    break;
                
                case "u":
                    global.facing = 2;
                    break;
                
                case "l":
                    global.facing = 3;
                    break;
            }
            
            obj_mainchara.set_facing();
            actor_id[jjj].visible = false;
            obj_mainchara.visible = true;
        }
    }
    
    for (var lll = 0; lll < 2; lll++)
    {
        if (i_ex(global.cinstance[lll]))
        {
            for (var jjj = 0; jjj < actor_count; jjj++)
            {
                if (actor_name[jjj] == global.cinstance[lll].name && i_ex(actor_id[jjj]))
                {
                    var myactor = actor_id[jjj];
                    
                    with (obj_caterpillarchara)
                    {
                        if (name == myactor.name)
                        {
                            setxy(myactor.x, myactor.y);
                            scr_caterpillar_interpolate(name);
                            scr_caterpillar_facing_single(name, myactor.facing);
                            depth = myactor.depth;
                        }
                    }
                    
                    global.cinstance[lll].visible = 1;
                    actor_id[jjj].visible = 0;
                }
            }
        }
    }
}
