function c_actortocaterpillar()
{
    c_cmd("actortocaterpillar", 0, 0, 0, 0);
}

function c_actortocaterpillarstill()
{
    c_cmd("actortocaterpillarstill", 0, 0, 0, 0);
}
