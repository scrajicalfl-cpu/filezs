function draw_ellipse_centered(arg0, arg1, arg2, arg3, arg4)
{
    d_ellipse(arg0 - (arg2 / 2), arg1 - (arg3 / 2), arg0 + (arg2 / 2), arg1 + (arg3 / 2), arg4);
}
