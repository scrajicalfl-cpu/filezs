function c_sel_sprite(arg0, arg1)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("sprite", arg1, 0, 0, 0);
}
