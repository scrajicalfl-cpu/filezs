function b_make(arg0 = 0, arg1 = 0, arg2 = 0, arg3 = 0, arg4 = -1)
{
    var xx = camerax();
    var yy = cameray();
    battlewriter = instance_create(xx + 30 + arg2, yy + 376 + arg3, obj_writer);
    myface = instance_create(xx + 26 + arg0, yy + 380 + arg1, obj_face);
    
    with (battlewriter)
    {
        dialoguer = 1;
        facer = 1;
        
        if (global.fc == 0 && originalcharline == 33)
            charline = 26;
        
        if (arg4 != -1)
            charline = arg4;
    }
}

function b_ex()
{
    return instance_exists(obj_writer);
}
