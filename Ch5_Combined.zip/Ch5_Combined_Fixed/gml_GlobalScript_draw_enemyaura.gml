function draw_enemyaura(arg0 = true, arg1 = sprite_width / 2, arg2 = 0, arg3 = false, arg4 = true)
{
    if (!sprite_exists(sprite_index))
        exit;
    
    if (!variable_instance_exists(id, "drawaura"))
        drawaura = true;
    
    if (!variable_instance_exists(id, "facing"))
        facing = 0;
    
    if (!variable_instance_exists(id, "drawsiner"))
        drawsiner = 0;
    
    if (!variable_instance_exists(id, "auraalph"))
        auraalph = 1;
    
    if (!variable_instance_exists(id, "fakescale"))
        fakescale = 2;
    
    var targ = -1;
    
    with (obj_mainchara)
        targ = x + 18;
    
    if (arg0 && targ != -1)
    {
        if (targ > arg1)
            facing = 1;
        else
            facing = 0;
    }
    
    if (drawaura)
    {
        specialspritecase = 0;
        drawx = 0;
        fakescale = abs(fakescale);
        
        if (facing == 1)
        {
            fakescale = -abs(fakescale);
            drawx = arg2;
        }
        
        drawsiner += 0.25;
        var remx = x;
        x += drawx;
        superscalexb = 1;
        drawx = 0;
        drawscale = 1;
        xoff = 0;
        
        if (facing == 1)
            drawscale = -1;
        
        drawsiner += 0.25;
        tempx = x;
        x += drawx;
        superscalex = 0;
        superdrawx = 0;
        superscalexb = 1;
        
        if (facing == 1)
        {
            superscalex = -4;
            superscalexb = -1;
            superdrawx = -sprite_width * 2;
            xoff = 0;
        }
        
        gpu_set_blendmode(bm_add);
        
        for (i = 0; i < 5; i++)
        {
            var aura = (i * 9) + ((drawsiner * 3) % 9);
            var aurax = (aura * 0.75) + (sin(aura / 4) * 4);
            var auray = 45 * scr_ease_in(aura / 45, 1);
            var aurayscale = min(80 / sprite_height, 1);
            draw_sprite_ext(sprite_index, image_index, x - xoff - ((aurax / 180) * drawscale * sprite_width), y - ((auray / 82) * sprite_height * aurayscale), (image_xscale + (aurax / 36)) * drawscale, image_yscale + ((auray / 36) * aurayscale), image_angle, c_red, image_alpha * (1 - (auray / 45)) * 0.5 * auraalph);
        }
        
        gpu_set_blendmode(bm_normal);
        var xmult = min((70 / sprite_width) * 4, 4);
        var ymult = min((80 / sprite_height) * 5, 5);
        var ysmult = min((80 / sprite_height) * 0.2, 0.2);
        draw_sprite_ext_centerscale(sprite_index, image_index, (x - xoff) + superdrawx + (sin(drawsiner / 5) * xmult), y + (cos(drawsiner / 5) * ymult), image_xscale + superscalex, image_yscale + (sin(drawsiner / 5) * ysmult), image_angle, 255, image_alpha * 0.2 * auraalph);
        draw_sprite_ext_centerscale(sprite_index, image_index, ((x - xoff) + superdrawx) - (sin(drawsiner / 5) * xmult), y - (cos(drawsiner / 5) * ymult), image_xscale + superscalex, image_yscale - (sin(drawsiner / 5) * ysmult), image_angle, 255, image_alpha * 0.2 * auraalph);
        scr_draw_outline_ext(sprite_index, image_index, x - xoff, y, image_xscale * drawscale, image_yscale, image_angle, c_red, image_alpha * 0.3, 2 * auraalph);
        x = tempx;
        mymidx = x + (sprite_width / 2);
        mymidy = y + ((bbox_bottom - y) / 2);
        x = remx;
    }
    
    if (!arg4)
        exit;
    
    if (facing == 0)
        draw_sprite_ext(sprite_index, image_index, x, y, 2, 2, 0, image_blend, image_alpha);
    else
        draw_sprite_ext(sprite_index, image_index, x + arg2, y, -2, 2, 0, image_blend, image_alpha);
}
