function scr_animate_complex(arg0, arg1, arg2, arg3, arg4 = 0)
{
    if (arg4 == "frames")
        arg4 = 0;
    
    if (arg4 == "seconds")
        arg4 = 1;
    
    var _frames_to_complete = 0;
    
    for (var i = 0; i < array_length(arg3); i++)
    {
        if (arg4 == 1)
            arg3[i] = round(arg3[i] * 30);
        
        show_debug_message_concat("scr_animate_complex: ", _frames_to_complete, " frames to complete frame: ", arg3[i]);
        _frames_to_complete += arg3[i];
    }
    
    show_debug_message_concat("scr_animate_complex: ", _frames_to_complete, " frames to complete animation: ", sprite_get_name(arg1));
    
    with (instance_create_depth(0, 0, 0, obj_animator_complex))
    {
        target = arg0;
        return_sprite = arg0.sprite_index;
        sprite = arg1;
        target.sprite_index = arg1;
        start_frame = arg2;
        target.image_index = arg2;
        timings_array = arg3;
    }
    
    return _frames_to_complete;
}

function c_animate_complex(arg0, arg1, arg2, arg3, arg4 = 0)
{
    if (arg4 == "frames")
        arg4 = 0;
    
    if (arg4 == "seconds")
        arg4 = 1;
    
    var _frames_to_complete = 0;
    
    for (var i = 0; i < array_length(arg3); i++)
    {
        if (arg4 == 1)
            arg3[i] = round(arg3[i] * 30);
        
        _frames_to_complete += arg3[i];
    }
    
    c_cmd_x("animcomplex", arg0, arg1, arg2, arg3, 0, 0);
    return _frames_to_complete;
}
