function scr_caterpillar_interpolate(arg0 = "none")
{
    if (arg0 == "all")
    {
        with (obj_caterpillarchara)
            scr_caterpillar_interpolate_old();
    }
    else if (arg0 == "none")
    {
        if (object_index == obj_caterpillarchara)
            scr_caterpillar_interpolate_old();
    }
    else
    {
        with (obj_caterpillarchara)
        {
            if (name == arg0)
                scr_caterpillar_interpolate_old();
        }
    }
}

function scr_caterinterp(arg0 = "none")
{
    scr_caterpillar_interpolate(arg0);
}

function scr_caterpillar_interpolate_old()
{
    var _newfacing = direction_to_object_bbox(id, 1198, true);
    remx[0] = obj_mainchara.x;
    remy[0] = obj_mainchara.y;
    facing[0] = _newfacing;
    
    for (var _iaia = target; _iaia > 0; _iaia -= 1)
    {
        remx[_iaia] = lerp(obj_mainchara.x, x + halign, _iaia / target);
        remy[_iaia] = lerp(obj_mainchara.y, y + valign, _iaia / target);
        facing[_iaia] = _newfacing;
    }
}
