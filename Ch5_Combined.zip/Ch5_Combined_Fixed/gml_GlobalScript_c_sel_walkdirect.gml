function c_sel_walkdirect(arg0, arg1, arg2, arg3)
{
    c_cmd("select", arg0, 0, 0, 0);
    c_cmd("walkdirect", arg1, arg2, arg3, 0);
}
