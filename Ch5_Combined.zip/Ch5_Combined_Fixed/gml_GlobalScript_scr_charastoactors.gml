function scr_charastoactors()
{
    with (obj_mainchara)
    {
        x = other.kr_actor.x;
        y = other.kr_actor.y;
    }
    
    with (obj_caterpillarchara)
    {
        if (name == "susie")
        {
            x = other.su_actor.x;
            y = other.su_actor.y;
        }
        else
        {
            x = other.ra_actor.x;
            y = other.ra_actor.y;
        }
    }
}
