function c_flip(arg0)
{
    c_cmd("flip", arg0, 0, 0, 0);
}

function c_flipinstance(arg0, arg1)
{
    c_cmd("flipinstance", arg0, arg1, 0, 0);
}
