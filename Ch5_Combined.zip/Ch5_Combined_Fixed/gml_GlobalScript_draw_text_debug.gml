function draw_text_debug(arg0, arg1, arg2, arg3 = 0, arg4 = 16777215)
{
}

function showtxt(arg0, arg1, arg2)
{
}
