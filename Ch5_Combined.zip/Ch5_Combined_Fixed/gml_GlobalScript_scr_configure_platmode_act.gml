function scr_configure_platmode_act(arg0, arg1, arg2, arg3)
{
    var helper = instance_create(x, y, obj_plat_targethelper);
    helper.owner = self;
    helper.effect = arg0;
    helper.char = arg1;
    helper.objectname = arg2;
    helper.description = arg3;
    
    if (!variable_instance_exists(id, "__plat_acts"))
        __plat_acts = [];
    
    array_push(__plat_acts, helper);
    return helper;
}

function scr_set_platmode_act_active(arg0, arg1 = "*")
{
    if (variable_instance_exists(id, "__plat_acts"))
    {
        for (var i = 0; i < array_length(__plat_acts); i++)
        {
            if (arg1 == "*" || __plat_acts.char == arg1)
                active = arg0;
        }
    }
}

function scr_destroy_platmode_act()
{
    if (variable_instance_exists(id, "__plat_acts"))
    {
        for (var i = 0; i < array_length(__plat_acts); i++)
        {
            with (__plat_acts[i])
                instance_destroy();
        }
    }
}
