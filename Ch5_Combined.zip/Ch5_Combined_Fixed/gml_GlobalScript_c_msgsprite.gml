function c_msgsprite(arg0, arg1 = -1, arg2 = -1, arg3 = -1, arg4 = -1, arg5 = -1)
{
    var actorcount = 0;
    
    with (obj_cutscene_master)
        actorcount = array_length(actor_id);
    
    if (arg0 > actorcount && instance_exists(arg0))
    {
        if (arg1 != -1)
            c_cmd_x("msgcmd", "var", arg0, "sprite_index", arg1, 0, 0);
        
        if (arg2 != -1)
            c_cmd_x("msgcmd", "var", arg0, "image_index", arg2, 0, 0);
        
        if (arg3 != -1)
            c_cmd_x("msgcmd", "var", arg0, "image_speed", arg3, 0, 0);
        
        if (arg4 != -1)
            c_cmd_x("msgcmd", "var", arg0, "image_alpha", arg4, 0, 0);
        
        if (arg5 != -1)
            c_cmd_x("msgcmd", "var", arg0, "image_blend", arg5, 0, 0);
    }
    else
    {
        c_sel(arg0);
        
        if (arg1 != -1)
            c_cmd_x("msgcmd", "sprite", arg1, 0, 0, 0, 0);
        
        if (arg2 != -1)
            c_cmd_x("msgcmd", "imageindex", arg2, 0, 0, 0, 0);
        
        if (arg3 != -1)
            c_cmd_x("msgcmd", "imagespeed", arg3, 0, 0, 0, 0);
        
        if (arg4 != -1)
            c_cmd_x("msgcmd", "var", 0, "image_alpha", arg4, 0, 0);
        
        if (arg5 != -1)
            c_cmd_x("msgcmd", "var", 0, "image_blend", arg5, 0, 0);
    }
}

function c_sprite_set(arg0, arg1 = -1, arg2 = -1, arg3 = -1, arg4 = -1, arg5 = -1)
{
    var actorcount = 0;
    
    with (obj_cutscene_master)
        actorcount = array_length(actor_id);
    
    if (arg0 > actorcount && instance_exists(arg0))
    {
        if (arg1 != -1)
            c_var_instance(arg0, "sprite_index", arg1);
        
        if (arg2 != -1)
            c_var_instance(arg0, "image_index", arg2);
        
        if (arg3 != -1)
            c_var_instance(arg0, "image_speed", arg3);
        
        if (arg4 != -1)
            c_var_instance(arg0, "image_alpha", arg4);
        
        if (arg5 != -1)
            c_var_instance(arg0, "image_blend", arg5);
    }
    else
    {
        c_sel(arg0);
        
        if (arg1 != -1)
            c_var("sprite_index", arg1);
        
        if (arg2 != -1)
            c_var("image_index", arg2);
        
        if (arg3 != -1)
            c_var("image_speed", arg3);
        
        if (arg4 != -1)
            c_var("image_alpha", arg4);
        
        if (arg5 != -1)
            c_var("image_blend", arg5);
    }
}

function c_delay_sprite(arg0, arg1, arg2 = -1, arg3 = -1, arg4 = -1, arg5 = -1, arg6 = -1)
{
    var actorcount = 0;
    
    with (obj_cutscene_master)
        actorcount = array_length(actor_id);
    
    if (arg1 > actorcount && instance_exists(arg1))
    {
        c_delay_customfunc(arg0, function(arg0)
        {
            var actor = arg0[0];
            var spr = arg0[1];
            var index = arg0[2];
            var spd = arg0[3];
            var alpha = arg0[4];
            var blend = arg0[5];
            
            with (actor)
            {
                if (spr != -1)
                    sprite_index = spr;
                
                if (index != -1)
                    image_index = index;
                
                if (spd != -1)
                    image_speed = spd;
                
                if (alpha != -1)
                    image_alpha = alpha;
                
                if (blend != -1)
                    image_blend = blend;
            }
        }, [arg1, arg2, arg3, arg4, arg5, arg6]);
    }
    else
    {
        c_delay_customfunc(arg0, function(arg0)
        {
            var actor = arg0[0];
            var spr = arg0[1];
            var index = arg0[2];
            var spd = arg0[3];
            var alpha = arg0[4];
            var blend = arg0[5];
            
            with (obj_cutscene_master)
            {
                with (actor_id[actor])
                {
                    if (spr != -1)
                        sprite_index = spr;
                    
                    if (index != -1)
                        image_index = index;
                    
                    if (spd != -1)
                        image_speed = spd;
                    
                    if (alpha != -1)
                        image_alpha = alpha;
                    
                    if (blend != -1)
                        image_blend = blend;
                }
            }
        }, [arg1, arg2, arg3, arg4, arg5, arg6]);
    }
}

function sprite_set(arg0 = id, arg1 = -1, arg2 = -1, arg3 = -1, arg4 = -99, arg5 = -1, arg6 = -999, arg7 = -999)
{
    with (arg0)
    {
        if (arg1 != -1)
            sprite_index = arg1;
        
        if (arg2 != -1)
            image_index = arg2;
        
        if (arg3 != -1)
            image_speed = arg3;
        
        if (arg4 != -99)
            image_alpha = arg4;
        
        if (arg5 != -1)
            image_blend = arg5;
        
        if (arg6 != -999)
            image_xscale = arg6;
        
        if (arg7 != -999)
            image_yscale = arg7;
    }
}
