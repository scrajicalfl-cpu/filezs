function draw_self_xy(arg0, arg1)
{
    draw_sprite_ext(sprite_index, image_index, arg0, arg1, image_xscale, image_yscale, image_angle, image_blend, image_alpha);
}
