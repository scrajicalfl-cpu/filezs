function draw_surface_centered(arg0, arg1, arg2)
{
    draw_surface(arg0, arg1 - (surface_get_width(arg0) / 2), arg2 - (surface_get_height(arg0) / 2));
}
