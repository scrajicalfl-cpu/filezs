function scr_battlebg_fullalpha()
{
    with (obj_battleback)
        return image_alpha >= 1;
    
    return false;
}
