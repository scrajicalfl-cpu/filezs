function ossafe_init()
{
}
