function lerp_inout_quint(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_quint(arg2, 0, 1, 1));
}

function lerp_inout_quart(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_quart(arg2, 0, 1, 1));
}

function lerp_inout_quad(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_quad(arg2, 0, 1, 1));
}

function lerp_inout_expo(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_expo(arg2, 0, 1, 1));
}

function lerp_inout_elastic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_elastic(arg2, 0, 1, 1));
}

function lerp_inout_cubic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_cubic(arg2, 0, 1, 1));
}

function lerp_inout_circ(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_circ(arg2, 0, 1, 1));
}

function lerp_inout_bounce(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_bounce(arg2, 0, 1, 1));
}

function lerp_inout_back(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_inout_back(arg2, 0, 1, 1));
}

function lerp_out_quint(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_quint(arg2, 0, 1, 1));
}

function lerp_out_quart(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_quart(arg2, 0, 1, 1));
}

function lerp_out_quad(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_quad(arg2, 0, 1, 1));
}

function lerp_out_expo(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_expo(arg2, 0, 1, 1));
}

function lerp_out_elastic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_elastic(arg2, 0, 1, 1));
}

function lerp_out_cubic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_cubic(arg2, 0, 1, 1));
}

function lerp_out_circ(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_circ(arg2, 0, 1, 1));
}

function lerp_out_bounce(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_bounce(arg2, 0, 1, 1));
}

function lerp_out_back(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_out_back(arg2, 0, 1, 1));
}

function lerp_in_quint(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_quint(arg2, 0, 1, 1));
}

function lerp_in_quart(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_quart(arg2, 0, 1, 1));
}

function lerp_in_quad(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_quad(arg2, 0, 1, 1));
}

function lerp_in_expo(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_expo(arg2, 0, 1, 1));
}

function lerp_in_elastic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_elastic(arg2, 0, 1, 1));
}

function lerp_in_cubic(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_cubic(arg2, 0, 1, 1));
}

function lerp_in_circ(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_circ(arg2, 0, 1, 1));
}

function lerp_in_bounce(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_bounce(arg2, 0, 1, 1));
}

function lerp_in_back(arg0, arg1, arg2)
{
    return lerp(arg0, arg1, ease_in_back(arg2, 0, 1, 1));
}
