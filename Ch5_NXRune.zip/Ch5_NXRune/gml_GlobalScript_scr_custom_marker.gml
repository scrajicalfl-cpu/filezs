function scr_custom_marker(arg0, arg1, arg2, arg3)
{
    thismarker = instance_create(arg1, arg2, arg0);
    
    with (thismarker)
    {
        sprite_index = arg3;
        image_speed = 0;
    }
    
    return thismarker;
}
